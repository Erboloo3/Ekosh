from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Movie, Review

@login_required
def review_list(request):
    reviews = Review.objects.all()
    return render(request, 'reviews/review_list.html', {'reviews': reviews})

@login_required
def review_detail(request, review_id):
    review = Review.objects.get(id=review_id)
    return render(request, 'reviews/review_detail.html', {'review': review})

@login_required
def review_create(request):
    if request.method == 'POST':
        movie_id = request.POST.get('movie_id')
        user = request.POST.get('user')
        comment = request.POST.get('comment')
        review = Review(movie_id=movie_id, user=user, comment=comment)
        review.save()
        return redirect('review_detail', review_id=review.id)
    else:
        movies = Movie.objects.all()
        return render(request, 'reviews/review_form.html', {'movies': movies})

@login_required
def review_edit(request, review_id):
    review = Review.objects.get(id=review_id)
    if request.method == 'POST':
        movie_id = request.POST.get('movie_id')
        user = request.POST.get('user')
        comment = request.POST.get('comment')
        review.movie_id = movie_id
        review.user = user
        review.comment = comment
        review.save()
        return redirect('review_detail', review_id=review.id)
    else:
        movies = Movie.objects.all()
        return render(request, 'reviews/review_form.html', {'movies': movies, 'review': review})

@login_required
def review_delete(request, review_id):
    review = Review.objects.get(id=review_id)
    review.delete()
    return redirect('review_list')

